
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/trending.js
async function handler(event, context) {
  const { category = "toys", days = 7 } = JSON.parse(event.body || "{}");
  const trends = generateMockTrends(category, days);
  return {
    statusCode: 200,
    body: JSON.stringify({ trends, fetchedAt: (/* @__PURE__ */ new Date()).toISOString() })
  };
}
function generateMockTrends(category, days) {
  const toyKeywords = [
    { keyword: "slime kits for kids", category: "STEM", score: 92 },
    { keyword: "ootdoor water toys", category: "Outdoor", score: 88 },
    { keyword: "kids coding robot", category: "STEM", score: 85 },
    { keyword: "sensory play sets", category: "Sensory", score: 81 },
    { keyword: "tiktok viral toys 2026", category: "Viral", score: 95 },
    { keyword: "magnetic building tiles", category: "STEM", score: 79 },
    { keyword: "kids escape room game", category: "Games", score: 76 },
    { keyword: "balance bike toddler", category: "Outdoor", score: 74 },
    { keyword: "glow in dark craft supplies", category: "Arts", score: 72 },
    { keyword: "stem subscription box", category: "STEM", score: 70 },
    { keyword: "kids microscope set", category: "STEM", score: 68 },
    { keyword: "play dough variety pack", category: "Sensory", score: 67 },
    { keyword: "card game family edition", category: "Games", score: 65 },
    { keyword: "kite for kids", category: "Outdoor", score: 63 },
    { keyword: "dress up costume set", category: "Dress Up", score: 61 }
  ];
  return toyKeywords.map((t) => ({
    ...t,
    source: "mock",
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    searchVolume: Math.floor(Math.random() * 5e4) + 1e4,
    trendDirection: Math.random() > 0.3 ? "rising" : "stable"
  }));
}
export {
  handler as default
};
