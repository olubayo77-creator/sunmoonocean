
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/scheduler.js
var SENDGRID_API_KEY = process.env.SENDGRID_API_KEY || "";
var ADMIN_EMAIL = process.env.ADMIN_EMAIL || "";
var DAILY_DIGEST_RECIPIENT = process.env.DAILY_DIGEST_RECIPIENT || ADMIN_EMAIL;
async function handler(event, context) {
  console.log("SunMoonOcean daily pipeline triggered at", (/* @__PURE__ */ new Date()).toISOString());
  try {
    const pipelineResult = await runPipeline();
    if (SENDGRID_API_KEY && DAILY_DIGEST_RECIPIENT) {
      await sendDailyDigest(pipelineResult);
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Daily pipeline completed",
        pipeline: pipelineResult,
        email: SENDGRID_API_KEY ? "sent" : "skipped (no key)"
      })
    };
  } catch (error) {
    console.error("Pipeline error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
}
async function runPipeline() {
  return {
    analyzed: 12,
    newCandidates: 3,
    topScorer: "Galaxy Slime Lab Kit",
    trendScore: 92,
    runAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function sendDailyDigest(pipelineResult) {
  if (!SENDGRID_API_KEY) return;
  const emailData = {
    to: DAILY_DIGEST_RECIPIENT,
    from: "noreply@sunmoonocean.com",
    subject: `\u{1F525} SunMoonOcean Daily Digest - ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`,
    text: `
SunMoonOcean Daily Pipeline Report
===================================
Analyzed: ${pipelineResult.analyzed} products
New candidates: ${pipelineResult.newCandidates}
Top product: ${pipelineResult.topScorer} (score: ${pipelineResult.trendScore})
Run at: ${pipelineResult.runAt}

Log in to your dashboard to review and approve products.
    `,
    html: `
<h2>\u{1F525} SunMoonOcean Daily Pipeline Report</h2>
<p><strong>Analyzed:</strong> ${pipelineResult.analyzed} products</p>
<p><strong>New candidates:</strong> ${pipelineResult.newCandidates}</p>
<p><strong>Top product:</strong> ${pipelineResult.topScorer} (score: ${pipelineResult.trendScore})</p>
<p><strong>Run at:</strong> ${pipelineResult.runAt}</p>
<hr/>
<p>Log in to your dashboard to review and approve products.</p>
    `
  };
  try {
    const response = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${SENDGRID_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(emailData)
    });
    console.log("Email sent, status:", response.status);
  } catch (error) {
    console.error("SendGrid error:", error.message);
  }
}
export {
  handler as default
};
