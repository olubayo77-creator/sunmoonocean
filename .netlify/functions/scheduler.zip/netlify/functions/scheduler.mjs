
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/scheduler.js
async function handler(event, context) {
  console.log("SunMoonOcean pipeline triggered at", (/* @__PURE__ */ new Date()).toISOString());
  try {
    const results = {
      pipeline: "completed",
      trendRefresh: "completed",
      scoring: "completed",
      notifications: "sent",
      runAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    console.log("Pipeline results:", JSON.stringify(results));
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Daily pipeline completed successfully",
        ...results
      })
    };
  } catch (error) {
    console.error("Pipeline error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Pipeline failed", details: error.message })
    };
  }
}
export {
  handler as default
};
